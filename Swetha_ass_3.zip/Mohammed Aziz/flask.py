from flask import Flask
app = Flask(_name_)


'''If everything works fine you will get a
message that Flask is working on the first
page of the application
'''

@app.route('/')
def check():
	return 'Flask is working'


if _name_ == '_main_':
	app.run()